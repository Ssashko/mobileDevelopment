import { StyleSheet, View, Text, ImageBackground, Vibration } from 'react-native';
import React, {useState, useEffect} from "react";
import ImageTitle from '../assets/tomato.png';
import Button from './button.js';

export default function Timer(props) {
  const [elapsed, setElapsed] = useState(0);
  const [timeStamp, setTimeStamp] = useState(null);
  const [curryElapsed, setCurryElapsed] = useState(0);
  const getTime = () => props.time * 60 * 1000;
  useEffect(() => {
      let interval = setInterval(() => {
        if(timeStamp !== null)
          setElapsed(Date.now() - timeStamp + curryElapsed);
      }, 10);

      if(getTime() <= elapsed)
      {
        setTimeStamp(null); 
        setCurryElapsed(0);
        if(props.vibration)
          Vibration.vibrate(10 * 1000);
        console.log(elapsed);
      }

      return ()=> {
        clearInterval(interval);
      }; 
  },[elapsed, timeStamp])
  const clearState = () => {
    setTimeStamp(null); 
    setElapsed(0); 
    setCurryElapsed(0);
  };
  return (
    <View>
    {
    props.show ?
    (
    <View style={styles.container}>
    <ImageBackground 
      source={ImageTitle}
      style={styles.timerWrapper}
      resizeMode="center"
    >
        <View style={styles.timer}>
          <Text style={styles.timerVal}>{getTimeRepresentation(new Date (Math.max(0, getTime() - elapsed)))}</Text>
        </View>
    </ImageBackground>
      <View style={styles.panelControl}>
        <Button
        style={styles.control}
        text="&#8635;"
        onClick={clearState}
        />
        <Button
        style={styles.control}
        text={timeStamp === null ? <>&#9654;</> : <>&#10074;&#10074;</>}
        onClick={() => {
          setTimeStamp(timeStamp === null ? Date.now() : null);
          setCurryElapsed(elapsed);
        }}
        />
        <Button
        style={styles.control}
        text="&#10005;"
        onClick={() => {
          clearState();
          props.onClose()
        }}
        />
      </View>
      </View>)
    : null
   }
   </View>
  );
}

function getTimeRepresentation(time)
{
  return getTwoDigitNumber(time.getMinutes()) + ":" + getTwoDigitNumber(time.getSeconds()) + "," + getTwoDigitNumber(Math.round(time.getMilliseconds()/10));
}

function getTwoDigitNumber(num)
{
  const res = num.toString()
  return (res.length == 1 ? "0" : "") + res;
}

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    alignItems: "center",
    margin: 150,

  },
  timerWrapper: {
    height: 350,
    width: 350,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#290205",
    borderRadius: 350,
  },
  timer: {
    backgroundColor: "red",
    padding: 15,
    marginTop: 100,
    width: 300,
    borderRadius: 50,
    borderWidth: 5,
    borderColor: "#290205"
  },
  timerVal: {
    fontSize: 30,
    fontWeight: "bold",
    textAlign: "center",
    color: "white"
  },
  panelControl: {
    flexDirection: "row",
    marginTop: 80
  },
  control: {
    margin: 10
  }

});