import React, {useState} from "react";
import { StyleSheet, View, Text,Pressable } from 'react-native';

export default function Switcher(props) {
    const [type,setType] =  useState(true);
    return (
    <View style={StyleSheet.flatten([styles.root, props.style])}>
      <Pressable style={type ? styles.activePart : styles.passivePart} 
      onPress={() => {setType(true); props.onFirst();}}>
        <Text style={type ? styles.whiteText : styles.blackText}>{props.firstText}</Text>
      </Pressable>
      <Pressable style={!type ? styles.activePart : styles.passivePart}
      onPress={() => {setType(false); props.onSecond();}}>
        <Text style={!type ? styles.whiteText : styles.blackText}>{props.secondText}</Text>
      </Pressable>
      </View>
    );
  }

const styles = StyleSheet.create({
    root: {
        flexDirection: "row",
        height: 50,
        borderWidth: 10,
        borderColor: "#f70519",
        borderRadius: 10,

        shadowColor: "#f70519",
        shadowOffset: {
            width: 0,
            height: 12,
        },
        shadowOpacity: 0.58,
        shadowRadius: 16.00,

        elevation: 24,
    },
    activePart: {
      backgroundColor: "#ba0918",
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      borderWidth: 3,
      borderColor: "#8a000b",
    },
    passivePart: {
        backgroundColor: "#fccace",
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        
    },
    whiteText: {
        fontWeight: "bold",
        color: "white",
    },
    blackText: {
        fontWeight: "bold",
        color: "black",
    }
});