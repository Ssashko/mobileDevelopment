import { StyleSheet, View, Text, ImageBackground } from 'react-native';
import React, {useState} from "react";
import Switcher from './switcher.js';
import Button from './button.js';
import ImageTitle from '../assets/tomato.png';

export default function Menu(prop) {
    const [timerValue, setTimerValue] = useState(5);
    const [vibration, setVibration] = useState(true);
  return (
    <View>
    { prop.show ? (
    <View style={styles.container}>
    <ImageBackground 
    source={ImageTitle}
    style={styles.titleWrapper}
    resizeMode="center"
    >
      <View style={styles.title}>
        <Text style={styles.titleFirst}>Pomodoro</Text>
        <Text style={styles.titleSecond}>Таймер</Text>
      </View>
    </ImageBackground>
    <Switcher 
    style={styles.switcher}
    firstText="5 хвилин" 
    secondText="25 хвилин"
    onFirst={() => setTimerValue(5)}
    onSecond={() => setTimerValue(25)}
    />
    <Switcher
    style={styles.switcher}
    firstText="вібрація" 
    secondText="безшумний режим"
    onFirst={() => setVibration(true)}
    onSecond={() => setVibration(false)}
    />
    <Button
    style={styles.start}
    text="&#9654;"
    onClick={() => prop.onStart(timerValue, vibration)}
    />
    </View>
    ) : null
    }
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    margin: 20,
    alignItems: "center",
    justifyContent: "space-between"
  },
  titleWrapper: {
    height: 300,
    width: 300,
    justifyContent: 'center',
    alignItems: "center"
  },
  title: {
    marginTop: 60,
    marginLeft: 10,
    backgroundColor: "red",
    padding: 10,
    borderRadius: 50,
    borderWidth: 5,
    borderColor: "white"
  },
  titleFirst: {
    textAlign: "center",
    fontWeight: "bold",
    color: "white",
    fontSize: 20
  },
  titleSecond: {
    textAlign: "center",
    color: "#590e14",
    fontWeight: "bold",
  },
  start: {
    marginTop: 100,
    width: 100,
    height: 50,
  },
  switcher: {
    marginTop: 50
  }

});
