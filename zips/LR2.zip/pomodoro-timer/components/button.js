import React, {useState} from "react";
import { StyleSheet, Text, Pressable } from 'react-native';

export default function Button(props) {
    const [clicking, setClicking] = useState(false);
    return (
      <Pressable style={StyleSheet.flatten([clicking ? styles.clicking : styles.normal, props.style])} 
      onPressIn={() => setClicking(true)}
      onPressOut={() => {setClicking(false); props.onClick();}}
      >
        <Text style={styles.text}>{props.text}</Text>
      </Pressable>
    );
}


const styles = StyleSheet.create({
    clicking: {
        backgroundColor: "#540309",
        justifyContent: "center",
        alignItems: "center",
        width: 80,
        borderWidth: 3,
        padding: 5,
        borderColor: "#290205",

        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 12,
        },
        shadowOpacity: 0.58,
        shadowRadius: 16.00,

        elevation: 24,
    },

    normal: {
        backgroundColor: "#ba0918",
        justifyContent: "center",
        alignItems: "center",
        borderWidth: 3,
        padding: 5,
        borderColor: "#8a000b",
        width: 80,
        shadowColor: "#ba0918",
        shadowOffset: {
            width: 0,
            height: 12,
        },
        shadowOpacity: 0.58,
        shadowRadius: 16.00,

        elevation: 24,
    },

    text: {
        color: "white",
        fontWeight: "bold",
        fontSize: 25
    }
});