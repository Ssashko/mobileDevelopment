import React, {useState} from "react";
import { View } from 'react-native';
import Menu from './components/menu.js';
import Timer from './components/timer.js';

export default function App(prop) {
  const [showMenu, setShowMenu] = useState(true);
  const [timerValue, setTimerValue] = useState(5);
  const [vibration, setVibration] = useState(true);

  return (
    <View>
      <Menu show={showMenu} onStart={(timerValue, vibration) => {setTimerValue(timerValue); setVibration(vibration); setShowMenu(false)}}/>
      <Timer show={!showMenu} time={timerValue} vibration={vibration} onClose={() => setShowMenu(true)} />
    </View>
  );
}

