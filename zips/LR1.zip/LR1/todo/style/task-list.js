import { StyleSheet } from "react-native";

const TaskListStyle = StyleSheet.create({
    TaskListItemView: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "#e6e6e6",
        marginTop: 10,
        
    },
    TaskListItemTextInput: {
        flexGrow: 1,
        
    },
    TaskListItemCheckbox: {
        margin: 5
    },
    View: {
        margin: 10
    },
    Text: {
        padding: 10,
        textAlign: "center",
        backgroundColor: "#e6e6e6",
    },
    Title: {
        backgroundColor: "#4287f5",
        color: "white",
        marginTop: 20,
        fontSize: 20,
        fontWeight: "bold"
    },
    AddButton: {
        marginTop: 10,
        backgroundColor: "black",
        color: "white",
    }
    
});

export default TaskListStyle;