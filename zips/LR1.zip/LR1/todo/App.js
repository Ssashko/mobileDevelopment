import React, { useState } from 'react';
import {Text, View } from 'react-native';

import TaskList from './component/task-list';
import TaskListStyle from './style/task-list';

export default function App() {
  const [countTask, setCountTask] = useState(0);
  const [countUncheckedTask, setCountUncheckedTask] = useState(0);
  return (
    <View style={TaskListStyle.View}>
        <Text style={TaskListStyle.Title}>Todo App</Text>
        <Text style={TaskListStyle.Text}>
          task count : {countTask}
        </Text>
        <Text style={TaskListStyle.Text}>
          count unchecked task : {countUncheckedTask}
        </Text>
        <TaskList 
        countTaskCallback={setCountTask}
        countUncheckedTaskCallback={setCountUncheckedTask}
        />
    </View>
  );
}