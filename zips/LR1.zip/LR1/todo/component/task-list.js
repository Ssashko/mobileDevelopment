import React, { useState, useRef } from 'react';
import { FlatList, View, Button } from 'react-native';

import TaskItem from './task-list-item';
import TaskListStyle from '../style/task-list';


export default function TaskList(props)
{
    const [list, setList] = useState({});
    let nextId = useRef(0);
    let taskCount = useRef(0);
    let uncheckedCount = useRef(0);
    let addTask = () =>
    {
        props.countTaskCallback(++taskCount.current);
        props.countUncheckedTaskCallback(++uncheckedCount.current);
        list[nextId.current++] = {name : "To do title", checked : false};
        setList(list);
    }
    function checkTaskCallback(id, val)
    {
        uncheckedCount.current += (val ? -1 : 1)
        props.countUncheckedTaskCallback(uncheckedCount.current);
        list[id].checked = val;
        setList(list);
    }

    function deleteTaskCallback(id, val)
    {
        console.log(val);
        uncheckedCount.current += (val ? 0 : -1)
        props.countUncheckedTaskCallback(uncheckedCount.current);
        props.countTaskCallback(--taskCount.current);
        delete list[id];
        console.log(list);
        setList(list);
    }
    return (
        <View>
            <Button
            style={TaskListStyle.View}
            onPress={addTask}
            title="Add Task"
            />
            <FlatList
            data={Object.entries(list)}
            renderItem={({item}) => <TaskItem id={item[0]} name={item[1].name} checked={item[1].checked} checkCallback={checkTaskCallback} deleteCallback={deleteTaskCallback} />}
            keyExtractor={item => item[0]}
            />
        </View>
      );
}