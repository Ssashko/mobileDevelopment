import React, { useState } from 'react';
import {View, TextInput, Button } from 'react-native';

import Checkbox from 'expo-checkbox';
import TaskListStyle from '../style/task-list';

export default function TaskItem(props)
{
    const [checked, setChecked] = useState(props.checked);
    const [name, setName] = useState(props.name);
    return (
        <View style={TaskListStyle.TaskListItemView}>
            <Checkbox 
            style={TaskListStyle.TaskListItemCheckbox}
            value = {checked}
            onValueChange = {(val) => {
                props.checkCallback(props.id, val);
                setChecked(val);
            }}
            />
            <TextInput 
            style={TaskListStyle.TaskListItemTextInput}
            defaultValue={name}
            onChangeText = {setName}
            />
            <Button
            style={TaskListStyle.TaskListItemButton}
            onPress={() => props.deleteCallback(props.id, checked)}
            title="✖"
            />
        </View>
    );
}