module.exports = {
    asserts: ['./assets/fonts'],
}