import React from 'react';
import { View, FlatList, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function List({ navigation, route }) {
  const { movies } = route.params;
  return (
    <View>
      <FlatList
        data={movies}
        keyExtractor={item => item.imdbID}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => navigation.navigate('Detail', { id: item.imdbID })}
          >
            <View style={styles.item}>
              <View style={styles.outerPoster}>
                <Image
                  style={styles.poster}
                  source={{ uri: item.Poster }}
                />
              </View>
              <Text style={styles.title}>{item.Title} ({item.Year})</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    borderBottomWidth: 3,
    borderColor: '#00368c',
    backgroundColor: "#8da2c4",
  },
  outerPoster: {
    borderWidth: 1,
    borderColor: 'black',
    backgroundColor: '#d4d6d9',
    justifyContent:'center',
    alignItems: 'center',
    height: 100,
    width: 100,
    
  },
  poster: {
    width: 95,
    height: 95,
    resizeMode:'contain',
    margin: 10
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'Roboto'
  },
});
