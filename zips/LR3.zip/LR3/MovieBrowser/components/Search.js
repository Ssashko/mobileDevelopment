import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

const apiKey = 'cbaad34'

export default function Search({ navigation }) {
  const [searchRequest, setSearchRequest] = useState('');

  const onSearch = () => {
    fetch(`http://www.omdbapi.com/?apikey=${apiKey}&s=${searchRequest}`)
      .then(response => response.json())
      .then(data => {
        if (data.Search) {
            const pages = Math.ceil(data.totalResults / 10);
            const promises = [];
            for (let i = 1; i <= pages; i++) {
              promises.push(
                fetch(`http://www.omdbapi.com/?apikey=${apiKey}&s=${searchRequest}&page=${i}`)
                  .then(response => response.json())
                  .then(data => data.Search)
              );
            }
            Promise.all(promises).then(results => navigation.navigate('List', { movies: results.flat() }));
          }
      }) 
      .catch(error => {});
  };
  

  return (
    <View style={styles.view}>
      <View style={styles.innerView}>
      <TextInput
        style={styles.input}
        placeholder="Search for movies..."
        onChangeText={text => setSearchRequest(text)}
        value={searchRequest}
      />
      <Button title="Search" onPress={onSearch} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  view: {
    justifyContent:'center',
    alignItems: 'center',
    backgroundColor: "#8da2c4",
    flexGrow: 1
  },
  innerView: {
    borderWidth: 2,
    borderColor: '#00368c',
    borderRadius: 10,
    backgroundColor: "white",
    padding: 50
  },
  input: {
    height: 40,
    width: 220,
    borderColor: '#00368c',
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
});
