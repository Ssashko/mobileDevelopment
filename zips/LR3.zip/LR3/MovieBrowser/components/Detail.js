import {React, useState, useEffect} from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const apiKey = 'cbaad34'

export default function Detail({ navigation, route }) {
  const [ movie, setMovie ] = useState(null);
  useEffect(() => {
      fetch(`http://www.omdbapi.com/?apikey=${apiKey}&i=${route.params.id}`)
      .then(response => response.json())
      .then(data => setMovie(data))
      .catch(error => {});
  }, []);
    return (
      <View style={styles.view}>
        {movie != null &&
          <View style={styles.innerView}>
            <View style={styles.outerPoster}>
              <Image
              style={styles.poster}
              source={{ uri: movie.Poster }}
              />
            </View>
          <Text style={styles.movieInfoTitle}>Title: {movie.Title}</Text>
          <Text style={styles.movieInfo}>Year: {movie.Year}</Text>
          <Text style={styles.movieInfo}>Type: {movie.Type}</Text>
          <Text style={styles.movieInfo}>Director: {movie.Director}</Text>
          <Text style={styles.movieInfo}>Plot: {movie.Plot}</Text>
          <Text style={styles.movieInfoID}>IMDB ID: {movie.imdbID}</Text>
          </View>
        }
      </View>
    );
}
const styles = StyleSheet.create({
  view: {
    justifyContent:'center',
    alignItems: 'center',
    backgroundColor: "#8da2c4",
    flexGrow: 1
  },
  innerView: {
    borderWidth: 2,
    borderColor: '#00368c',
    borderRadius: 10,
    backgroundColor: "white",
    padding: 50
  },
  outerPoster: {
    borderWidth: 1,
    borderColor: 'black',
    backgroundColor: '#999b9e',
    justifyContent:'center',
    alignItems: 'center',
    height: 200,
    width: 200
  },
  poster: {
    width: 200,
    height: 200,
    resizeMode:'contain',
  },
  movieInfo: {
    fontFamily: 'Roboto',
    
  },
  movieInfoTitle: {
    fontFamily: 'Roboto',
    fontSize: 20,
    fontWeight: 'bold',
  },
  movieInfoID: {
    color: 'red',
    fontSize: 10,
    marginTop: 10
  }
});
