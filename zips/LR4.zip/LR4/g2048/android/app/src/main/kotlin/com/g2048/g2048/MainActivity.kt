package com.g2048.g2048

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
